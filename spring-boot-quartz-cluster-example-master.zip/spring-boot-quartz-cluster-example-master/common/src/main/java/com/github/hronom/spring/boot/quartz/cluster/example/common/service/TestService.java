package com.github.hronom.spring.boot.quartz.cluster.example.common.service;

public interface TestService {
    void run(String id) throws Exception;
}
