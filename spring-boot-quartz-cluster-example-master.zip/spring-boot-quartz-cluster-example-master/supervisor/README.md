Tables creation scripts from `quartz-2.2.3-distribution.tar.gz/quartz-2.2.3-distribution.tar` that 
downloaded from here [http://www.quartz-scheduler.org/downloads/](http://www.quartz-scheduler.org/downloads/)
Scripts is in `/quartz-2.2.3/docs/dbTables`